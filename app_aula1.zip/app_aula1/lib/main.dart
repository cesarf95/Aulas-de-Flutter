

import 'package:flutter/material.dart';

void main() {
  runApp(const MeuApp());
}

class MeuApp extends StatelessWidget {
  const MeuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: TelaInicial(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class TelaInicial extends StatefulWidget {
  const TelaInicial({super.key});

  @override
  State<TelaInicial> createState() => _TelaInicialState();
}

class _TelaInicialState extends State<TelaInicial> {

  String mensagem = 'Nenhum botão clicado';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        
      ),

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            ElevatedButton(
              onPressed: () {
                setState(() {
                  mensagem = 'Botão clicado: Bom dia';
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
              ),
              child: const Text('Bom dia'),
            ),

            const SizedBox(height: 8),

            ElevatedButton(
              onPressed: () {
                setState(() {
                  mensagem = 'Botão clicado: Boa tarde';
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
              ),
              child: const Text('Boa tarde'),
            ),

            const SizedBox(height: 8),

            ElevatedButton(
              onPressed: () {
                setState(() {
                  mensagem = 'Botão clicado: Boa noite';
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Boa noite'),
            ),

            const SizedBox(height: 20),

            Text(
              mensagem,
              style: const TextStyle(fontSize: 22),
            ),

          ],
        ),
      ),
    );
  }
}